﻿
namespace SharedMessages.Commands
{
    public interface IGetProduct
    {
        public int Id { get; }
        public string Name { get; }
    }
}

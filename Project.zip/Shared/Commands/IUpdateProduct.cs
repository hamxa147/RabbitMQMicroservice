﻿
namespace SharedMessages.Commands
{
    public interface IUpdateProduct
    {
        public int Id {  get; set; }
        public string Name { get; set; }
    }
}

﻿namespace ProductsMicroservice.Entities
{
    public class Products
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
    }
}

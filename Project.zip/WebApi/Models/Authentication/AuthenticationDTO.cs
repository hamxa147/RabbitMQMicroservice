﻿namespace WebApi.Models.Authentication
{
    public class AuthenticationDTO
    {
        public string Email { get; set; }  
        public string Password { get; set; }    
    }
}
